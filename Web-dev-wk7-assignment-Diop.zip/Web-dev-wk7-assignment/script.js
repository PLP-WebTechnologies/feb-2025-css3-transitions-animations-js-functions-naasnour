// Animation trigger
document.getElementById("animateBtn").addEventListener("click", function () {
  const box = document.getElementById("animatedBox");
  box.classList.toggle("animate");
});

// Store and retrieve from localStorage
const form = document.getElementById("preferenceForm");
const colorInput = document.getElementById("colorInput");
const savedColorText = document.getElementById("savedColorText");

// Load saved color
window.onload = function () {
  const savedColor = localStorage.getItem("favoriteColor");
  if (savedColor) {
    savedColorText.textContent = `Your saved favorite color is: ${savedColor}`;
  }
};

// Save color to localStorage
form.addEventListener("submit", function (e) {
  e.preventDefault();
  const color = colorInput.value.trim();
  if (color) {
    localStorage.setItem("favoriteColor", color);
    savedColorText.textContent = `Your saved favorite color is: ${color}`;
    colorInput.value = "";
  }
});
